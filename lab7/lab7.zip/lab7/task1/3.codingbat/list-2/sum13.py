def sum13(a):
    sum = 0
    for i in a:
        if i==13:break
        sum+=i
    return sum