def common(a,b):
    if(a[0]==b[0] or a[len(a)-1]==b[len(b)-1]): return True
    return False