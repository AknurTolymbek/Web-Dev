def double_char(s):
    t=""
    for i in s:
        t+=(i*2)
    return t