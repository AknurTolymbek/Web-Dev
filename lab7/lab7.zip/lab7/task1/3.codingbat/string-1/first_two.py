def first_two(str):
    return str if len(str)<=2 else str[:2]