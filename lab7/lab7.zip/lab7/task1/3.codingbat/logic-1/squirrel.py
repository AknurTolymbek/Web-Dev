def squirell(temp,summer):
    if sum :
        return 60<= temp <=100
    return 60 <= temp <= 90