def stringTimes(s,x):
    return s*x
s = input()
x = int(input())
print(stringTimes(s,x))