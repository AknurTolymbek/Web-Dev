def array_count9(a):
  cnt = 0
  for num in a:
    if num == 9:
      cnt = cnt + 1
  return cnt