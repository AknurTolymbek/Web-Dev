a = int(input())

pow = 1
while pow <= a:
    print(pow, end = " ")
    pow *= 2