a = int(input())

i = 1
while i * i <= a:
    print(i * i)
    i += 1