N = int(input())
print(sum(int(input()) for _ in range(N)))