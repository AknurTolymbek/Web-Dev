a = int(input())
k = 0
pow = 1
while pow < a:
    pow *= 2
    k += 1
print(k)