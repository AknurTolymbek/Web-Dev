x = input()
d = input()

print(x.count(d))