x = input()

print(sum(map(int, x)))