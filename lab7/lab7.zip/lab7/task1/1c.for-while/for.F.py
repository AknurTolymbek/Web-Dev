x = input()

print(int(x[::-1]))