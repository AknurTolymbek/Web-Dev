k = int(input())
n = int(input())
a = n%k
print(a)