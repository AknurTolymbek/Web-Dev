a = int(input())
arr = list(map(int, input().split()))

for num in arr:
    if num % 2 == 0:
        print(num, end=" ")
