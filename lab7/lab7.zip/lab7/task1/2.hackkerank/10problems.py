""" 1
my_string = "Hello, World!"
print(my_string) 
"""

''' 2
import math
import os
import random
import re
import sys

if __name__ == '__main__':
    n = int(input().strip())

if n % 2 == 1:  
    print("Weird")
elif 2 <= n <= 5:  
    print("Not Weird")
elif 6 <= n <= 20:  
    print("Weird")
else:  
    print("Not Weird") '''

''' 3
if __name__ == '__main__':
    a = int(input())
    b = int(input())  

print(a + b)  
print(a - b)  
print(a * b)  
'''

''' 4
if __name__ == '__main__':
    n = int(input())
for i in range(n): 
    print(i ** 2)  
'''

''' 5
def is_leap(year):
    leap = False
    
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
    
    return leap

year = int(input())
print(is_leap(year))
'''

''' 6
if __name__ == '__main__':
    n = int(input())
print(*range(1, n+1), sep='')
'''

''' 7
if __name__ == '__main__':
    x = int(input())
    y = int(input())
    z = int(input())
    n = int(input())
result = [[i, j, k] for i in range(x + 1) for j in range(y + 1) for k in range(z + 1) if i + j + k != n]
print(result)
'''

''' 8
if __name__ == '__main__':
    N = int(input())
    lst = []  

    for _ in range(N):
        command = input().split()  
        if command[0] == "insert":
            lst.insert(int(command[1]), int(command[2]))
        elif command[0] == "print":
            print(lst)
        elif command[0] == "remove":
            lst.remove(int(command[1]))
        elif command[0] == "append":
            lst.append(int(command[1]))
        elif command[0] == "sort":
            lst.sort()
        elif command[0] == "pop":
            lst.pop()
        elif command[0] == "reverse":
            lst.reverse()
'''

''' 9
if __name__ == '__main__':
    n = int(input())
    student_marks = {}

    for _ in range(n):
        data = input().split()
        student_marks[data[0]] = list(map(float, data[1:]))

    query_name = input()
    print(f"{sum(student_marks[query_name]) / len(student_marks[query_name]):.2f}")
'''

''' 10
def print_full_name(first, last):
    print(f"Hello {first} {last}! You just delved into python.")

if __name__ == '__main__':
    first_name = input()
    last_name = input()
    print_full_name(first_name, last_name)
'''